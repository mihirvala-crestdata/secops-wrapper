"""Chronicle API specific functionality."""

from secops.chronicle.client import ChronicleClient

__all__ = ["ChronicleClient"] 